 <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bienvedinoooooooooooo</title>
</head>
<body>
    
    <?php

if ($_SERVER["REQUEST_METHOD"] == "POST") 
{
    $nombre = $_POST["nombre"];
    $password = $_POST["password"];
    echo "<h2>¡Pudiste entrar que padre!</h2>";
    echo "<p>Nombre: $nombre</p>";
    echo "<p>password: $password</p>";
} 
else
 {
    echo "Error: Acceso no autorizado.";
}
?>
<img src="Good.jpg" alt="Good">
</body>
</html> 
