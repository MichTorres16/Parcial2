<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulario PHP</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<h2>Formulario para ingresar a DataBase</h2>

<form method="post" action="otraPage.php">
    <label for="nombre">nombre:</label><br>
    <input type="text" id="nombre" name="nombre"><br>
    
    <label for="password">password</label><br>
    <input type="password" id="password" name="password"><br>
  
    
    <input type="submit" value="Enviar">
</form>
</body>
</html>

